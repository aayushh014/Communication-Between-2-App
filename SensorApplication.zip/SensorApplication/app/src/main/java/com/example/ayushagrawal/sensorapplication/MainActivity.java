package com.example.ayushagrawal.sensorapplication;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.renderscript.ScriptGroup;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.mbms.MbmsDownloadReceiver;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import static android.renderscript.ScriptGroup.*;

public class MainActivity extends AppCompatActivity {

    private EditText laserMin_txt;
    private EditText laserMax_txt;
    private TextView laserDist;
    private TextView lasertilt_Dist;
    private Button startbutton;
    private Button stopbutton;
    private EditText laserInterval;
    private Boolean flag = false;
    private final int WAIT_TIME = 2500;
    int distanceunit;
    int tilt_distanceunit;
    String tilt_distanceunit1;
    String distanceunit1;
    double min, max, a;
    long laser;
    String  laser1;
    private IRequestData cal=null;
    Context context;
    private BroadcastReceiver statusReceiver;
    String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        laserMax_txt = (EditText) findViewById(R.id.max);
        laserMin_txt = (EditText) findViewById(R.id.min);
        laserInterval = (EditText) findViewById(R.id.interval);
        startbutton = (Button) findViewById(R.id.start1);
        stopbutton = (Button) findViewById(R.id.stop1);
        laserDist = (TextView) findViewById(R.id.distnace);
        lasertilt_Dist = (TextView) findViewById(R.id.tilt);
        stopbutton = (Button) findViewById(R.id.stop1);
        stopbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag = false;

                try{


                           Intent it = getIntent();
                            String flag1 = it.getStringExtra("stop1");
                           flag = Boolean.valueOf(flag1);


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//
                flag = true;
                final Handler handler = new Handler();
                Runnable runnable = new Runnable() {
                    private long startTime = System.currentTimeMillis();

                    public void run() {

                        do {
                            if (laserMin_txt.getText() != null && laserMin_txt.getText().toString() != "" && laserMax_txt.getText() != null && laserMax_txt.getText().toString() != "" && laserInterval.getText() != null && laserInterval.getText().toString() != "") {
                                try {
                                    min = Double.parseDouble(laserMin_txt.getText().toString());
                                    max = Double.parseDouble(laserMax_txt.getText().toString());
                                    laser = Long.valueOf(laserInterval.getText().toString());
                                    handler.post(new Runnable() {
                                        public void run() {
                                            try {
                                                distanceunit = Integer.valueOf(distance(min, max));
                                                tilt_distanceunit = Integer.valueOf(tilt_distance(min, max));
                                                distanceunit1 = String.valueOf(distanceunit);
                                                tilt_distanceunit1 = String.valueOf(tilt_distanceunit);

                                                laserDist.setText("" + distanceunit1);
                                                lasertilt_Dist.setText("" + tilt_distanceunit1);//

                                                if(distanceunit!=0&& distanceunit1!=null && tilt_distanceunit!=0&& tilt_distanceunit1!=null && laserInterval.getText()!=null && laserInterval.getText().toString()!="")
                                                {
                                                Intent i = new Intent(MainActivity.this, MyService.class);
                                                i.putExtra("dist", distanceunit1);
                                                i.putExtra("tilt_dist", tilt_distanceunit1);
                                                startService(i);


                                            }


                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                flag = false;
                                            }

                                        }

                                    });

                                    long l = laser_interval(laser);
                                    try {
                                        Thread.sleep(l);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            Toast.makeText(getApplicationContext(), "Enter the correct Input in the given field", Toast.LENGTH_LONG).show();
                                        }
                                    });
                                    flag = false;
                                }
                            }

                        } while (flag == true);

                    }
                };
                new Thread(runnable).start();


            }

        });


    }


    public int distance(double min, double max) {

        a = Math.random() * ((max - min) + 1) + min;

        return (int) (a);
    }

    public int tilt_distance(double min, double max)

    {
        int t_max, t_min = 0;
        if (min >= 0 && max <= 10) {
            t_max = (200 / 100000);//nnn
        } else if (min >= 0 && max <= 100) {
            t_max = (200 / 10000);
        } else if (min >= 0 && max <= 1000) {
            t_max = (200 / 1000);
        } else if (min >= 0 && max <= 10000)

        {
            t_max = (200 / 100);
        } else if (min >= 0 && max <= 100000) {
            t_max = (200 / 10);
        } else {
            t_max = 200;
        }
        double t_dist = Math.random() * ((t_max - t_min) + 1) + t_min;
        double t = (t_dist + a);
        int c = (int) (Math.round(t));
        return c;
    }

    public int laser_interval(long interval) {

        return (int) interval;
    }

}




