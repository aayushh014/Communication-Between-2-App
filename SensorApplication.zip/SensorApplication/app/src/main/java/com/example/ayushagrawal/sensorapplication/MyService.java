package com.example.ayushagrawal.sensorapplication;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import java.net.URISyntaxException;

import static android.content.Intent.getIntent;
import static android.content.Intent.getIntentOld;

public class MyService extends Service {
    private static final String APP_TAG = "true";
    int set_distance, set_tilt_distance,set_laser;
    String take_distance, take_tilt_distance,get_laser;

    public MyService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        take_distance = intent.getStringExtra("dist");
        take_tilt_distance = intent.getStringExtra("tilt_dist");
        return flags;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
       return mBider;
    }


    private final IRequestData.Stub mBider = new IRequestData.Stub() {
        @Override
        public int distance(double min, double max) throws RemoteException {

            set_distance = Integer.valueOf(take_distance);
            return set_distance;
        }

        @Override
        public int tilt_distance(double min, double max) throws RemoteException {

            set_tilt_distance = Integer.valueOf(take_tilt_distance);
            return set_tilt_distance;
        }
        @Override
        public String stop(boolean flag)throws RemoteException {

            Intent ia=new Intent(MyService.this,MainActivity.class);
            flag=false;
            String f=String.valueOf(flag);
            ia.putExtra("stop1",f);
            startService(ia);
            return f;
        }

    };
}



