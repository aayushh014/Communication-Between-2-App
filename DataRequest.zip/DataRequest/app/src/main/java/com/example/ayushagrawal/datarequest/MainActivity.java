package com.example.ayushagrawal.datarequest;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ayushagrawal.sensorapplication.IRequestData;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    private Switch switchB;
    private TextView set_distance;
    private TextView set_tilt_distance;
    private IRequestData calService;
    private  double min,max;
    int result_dist,result_tilt_dist;
    boolean flag=false;
    boolean flag1=false;
    Handler handler = new Handler();
    Runnable refresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        set_distance = (TextView) findViewById(R.id.dist);
        set_tilt_distance = (TextView) findViewById(R.id.tilt);
        switchB = (Switch) findViewById(R.id.switch1);

        switchB.setOnCheckedChangeListener(this);


        }
        @Override
    protected void onStart() {
        super.onStart();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(connection);
    }
//
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(calService==null){

            Intent i =new Intent("GetData");
            bindService(convertImplicitIntentToExplicitIntent(i), connection ,BIND_AUTO_CREATE);

        }

        if (isChecked) {
           flag=true;

            Intent ittt=getPackageManager().getLaunchIntentForPackage("com.example.ayushagrawal.sensorapplication");
            startActivity(ittt);


            refresh = new Runnable() {
                public void run() {
                    handler.postDelayed(refresh, 500);
                    if(flag==true) {
                        try {

                            result_dist = Integer.valueOf(calService.distance(min, max));
                            result_tilt_dist = Integer.valueOf(calService.tilt_distance(min, max));
                            set_distance.setText("" + result_dist);
                            set_tilt_distance.setText("" + result_tilt_dist);


                        }catch(Exception e){


                            e.printStackTrace();

                        }
                    }
                }
            };
            handler.post(refresh);
        }
        else {
           flag=false;
            try {
                calService.stop(flag1);
                Toast.makeText(getApplicationContext(), " Service Stop", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                e.printStackTrace();

            }


            }
    }

    public ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            calService = IRequestData.Stub.asInterface(service);
            Toast.makeText(getApplicationContext(),	"Service Connected", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            calService = null;
            Toast.makeText(getApplicationContext(), "Service Disconnected", Toast.LENGTH_SHORT).show();
        }
    };

    public Intent convertImplicitIntentToExplicitIntent(Intent implicitIntent) {
        PackageManager pm = getPackageManager();
        List<ResolveInfo> resolveInfoList = pm.queryIntentServices(implicitIntent, 0);

        if (resolveInfoList == null || resolveInfoList.size() != 1) {
            return null;
        }
        ResolveInfo serviceInfo = resolveInfoList.get(0);
        ComponentName component = new ComponentName(serviceInfo.serviceInfo.packageName, serviceInfo.serviceInfo.name);
        Intent explicitIntent = new Intent(implicitIntent);
        explicitIntent.setComponent(component);
        return explicitIntent;
    }
}
